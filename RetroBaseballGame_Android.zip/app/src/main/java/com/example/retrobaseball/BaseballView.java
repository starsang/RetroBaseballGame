package com.example.retrobaseball;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import java.util.Random;

public class BaseballView extends View {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    Paint pixel = new Paint();
    Random rng = new Random();
    int inning=1, outs=0, balls=0, strikes=0, score=0, cpu=0;
    boolean pitching=false, ballFlying=false, resultShown=false;
    float bx, by, ballT=0f;
    int pitchType=0;
    String result="TAP PITCH TO THROW";
    long last=0;

    int W,H;
    int green=Color.rgb(52,160,67), dirt=Color.rgb(167,91,39), dark=Color.rgb(12,14,15);
    int white=Color.WHITE, yellow=Color.rgb(255,224,88);

    public BaseballView(Context c){ super(c); setFocusable(true); }

    void rect(Canvas c,int color,float l,float t,float r,float b){
        pixel.setColor(color); c.drawRect(l,t,r,b,pixel);
    }
    void txt(Canvas c,String s,float x,float y,float size,int color){
        p.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.BOLD));
        p.setTextSize(size); p.setColor(color); c.drawText(s,x,y,p);
    }

    @Override protected void onDraw(Canvas c){
        W=getWidth(); H=getHeight();
        c.drawColor(Color.BLACK);

        // retro scoreboard
        rect(c,Color.rgb(20,20,20),0,0,W,100);
        txt(c,"RETRO BASEBALL",22,36,24,white);
        txt(c,String.format("INNING %d",inning),W/2-65,34,20,yellow);
        txt(c,"YOU "+score+"  -  "+cpu+" CPU",W-245,36,19,white);
        txt(c,"B "+balls+"  S "+strikes+"  O "+outs,22,72,18,white);

        // stadium
        rect(c,Color.rgb(40,120,45),0,100,W,H);
        rect(c,Color.rgb(89,173,75),0,145,W,175);
        rect(c,dirt,0,175,W,250);
        rect(c,green,0,250,W,H);

        // distant seats
        for(int x=0;x<W;x+=18){
            rect(c,(x/18%2==0)?Color.rgb(45,70,160):Color.rgb(205,45,45),x,112,x+10,128);
        }

        // infield
        float cx=W/2f, cy=H*0.60f;
        p.setColor(dirt); c.drawCircle(cx,cy,125,p);
        p.setColor(Color.rgb(70,150,62)); c.drawCircle(cx,cy,100,p);
        drawBase(c,cx,cy+100); drawBase(c,cx-115,cy); drawBase(c,cx+115,cy);
        drawBase(c,cx,cy-100);

        // pitcher
        drawPlayer(c,cx,cy-35,Color.rgb(45,85,185),false);
        // batter
        drawPlayer(c,cx, H-165,Color.rgb(224,82,42),true);

        // ball
        if(ballFlying){
            bx = cx + (float)Math.sin(ballT*3.0)*18;
            by = cy+20 + ballT*(H-230-cy);
            p.setColor(Color.WHITE); c.drawCircle(bx,by,7,p);
        }

        // bottom panel
        rect(c,Color.BLACK,18,H-82,W-18,H-12);
        txt(c,pitching ? "SELECT PITCH" : "BATTER READY",34,H-51,19,yellow);
        txt(c,result,34,H-26,16,white);

        if(!pitching){
            button(c, W-245,H-70, W-140,H-25,"PITCH");
            button(c, W-125,H-70, W-25,H-25,"SWING");
        } else {
            button(c, W-355,H-70,W-255,H-25,"FAST");
            button(c, W-245,H-70,W-145,H-25,"CURVE");
            button(c, W-135,H-70,W-25,H-25,"SLIDER");
        }
        invalidate();
    }

    void drawBase(Canvas c,float x,float y){
        p.setColor(white); Path path=new Path();
        path.moveTo(x,y-9); path.lineTo(x+9,y); path.lineTo(x,y+9); path.lineTo(x-9,y); path.close();
        c.drawPath(path,p);
    }

    void drawPlayer(Canvas c,float x,float y,int shirt,boolean bat){
        rect(c,Color.BLACK,x-18,y-4,x+18,y+30);
        rect(c,shirt,x-15,y+2,x+15,y+29);
        p.setColor(Color.rgb(245,190,140)); c.drawCircle(x,y,14,p);
        rect(c,Color.BLACK,x-15,y-15,x+15,y-7);
        rect(c,Color.BLACK,x-22,y+27,x-5,y+39);
        rect(c,Color.BLACK,x+5,y+27,x+22,y+39);
        if(bat){
            rect(c,Color.rgb(190,135,65),x+13,y+10,x+65,y+16);
            rect(c,Color.rgb(120,75,35),x+8,y+8,x+20,y+18);
        }
    }

    void button(Canvas c,float l,float t,float r,float b,String s){
        rect(c,Color.rgb(28,28,28),l,t,r,b);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(white); c.drawRect(l,t,r,b,p); p.setStyle(Paint.Style.FILL);
        txt(c,s,l+12,t+30,15,white);
    }

    void startPitch(int type){
        pitchType=type; pitching=false; ballFlying=true; ballT=0f; resultShown=false; result="BALL IN PLAY!";
        last=System.currentTimeMillis();
    }

    void swing(){
        if(!ballFlying) return;
        float timing=Math.abs(ballT-0.72f);
        ballFlying=false;
        if(timing<0.08){
            int roll=rng.nextInt(100);
            if(roll<22){ score++; result="HOME RUN!"; }
            else if(roll<68){ result="HIT!  SINGLE"; }
            else { result="OUT!"; outs++; }
        } else if(timing<0.17){
            if(rng.nextBoolean()){ result="FOUL BALL"; strikes=Math.min(2,strikes+1); }
            else { result="OUT!"; outs++; }
        } else {
            strikes++; result="SWING & MISS";
        }
        advance();
    }

    void advance(){
        if(strikes>=3 || outs>=3){
            if(outs>=3){
                inning++; outs=0; balls=0; strikes=0;
                if(inning>9){ inning=1; score=0; cpu=0; result="NEW GAME"; }
                else result="CHANGE SIDES";
            }
        }
        if(balls>=4){ score++; balls=0; strikes=0; result="WALK!"; }
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_UP) return true;
        float x=e.getX(), y=e.getY();
        if(y<H-90) return true;

        if(!pitching){
            if(x>W-255 && x<W-135){ pitching=true; result="CHOOSE A PITCH"; }
            else if(x>W-140){ swing(); }
        } else {
            if(x>W-370 && x<W-255) startPitch(0);
            else if(x>W-255 && x<W-145) startPitch(1);
            else if(x>W-145) startPitch(2);
        }
        return true;
    }

    @Override protected void onSizeChanged(int w,int h,int ow,int oh){ W=w; H=h; }
}