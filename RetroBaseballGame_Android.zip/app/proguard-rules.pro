# Keep default rules for this prototype.
