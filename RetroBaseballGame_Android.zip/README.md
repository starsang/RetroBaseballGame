# 레트로 야구 Android 게임

레트로 픽셀 야구 게임 프로토타입입니다.

## 현재 구현
- 가로 화면 고정
- 1~9회 경기 흐름
- 투수: 직구 / 커브 / 슬라이더
- 타자: 타이밍 스윙
- 볼 / 스트라이크 / 아웃
- 안타 / 홈런 / 헛스윙 / 파울 / 볼넷
- 픽셀풍 경기장과 선수
- Android 7.0(API 24) 이상

## APK 빌드
Android Studio에서 프로젝트를 열어 `app`을 실행하거나,
GitHub에 업로드 후 Actions의 `Build APK`를 실행하면
`app-debug.apk`가 artifact로 생성됩니다.

현재 제작 환경에는 Android SDK/Build Tools가 설치되어 있지 않아
이 환경에서 APK 바이너리 자체까지 컴파일할 수는 없습니다.
